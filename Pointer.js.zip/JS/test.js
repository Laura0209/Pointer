window.onload = function(){
var px = event.clientX;
var py = event.clientY;

document.getElementById("art").onmousemove = function() {Drawcircle()};
document.getElementById("art").onclick = function() {Pointcircle()};
};