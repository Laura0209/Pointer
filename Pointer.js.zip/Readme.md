# Pointer.js
Pointers.js is a library for animations based on pointer location. The library needs the raphael.js library to function, you can download this library here: [Raphael.js](http://dmitrybaranovskiy.github.io/raphael/)

### Examples
  - [Placing circles](http://i345755.iris.fhict.nl/library/)
  - [Scatter circles](http://i345755.iris.fhict.nl/library/)

### Installation

Pointer.js requires [Raphael.js](http://dmitrybaranovskiy.github.io/raphael/) to run.

Install the libraries and use pointer.js as follow:

In javascript
```sh
window.onload = function(){
var px = event.clientX;
var py = event.clientY;

document.getElementById("art").onmousemove = function() {Drawcircle()};
};
```
"Art" is the element to move over to activate the function. 

In Html

```sh
<div id="art" onmousemove=""></div>
```

Feel free to change the onmousemove to onclick or any desired mouse action to change the behavior animation.
